﻿using System;
using System.Collections.Generic;
using System.Linq;

// Uncomment the following code if you use ReportsMobileModuleV2 module.
//using DevExpress.ExpressApp.ReportsV2.Mobile;

//namespace 家庭财务.Mobile {
//    public class DownloadReportService : XafDownloadReportService<家庭财务MobileApplication> { }
//}
