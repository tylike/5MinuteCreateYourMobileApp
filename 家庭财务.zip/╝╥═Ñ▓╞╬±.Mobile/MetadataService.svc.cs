﻿using System;
using DevExpress.ExpressApp.Mobile.Services;

namespace 家庭财务.Mobile {
    public class MetadataService : MobileMetadataService<家庭财务MobileApplication> {
	}
}
