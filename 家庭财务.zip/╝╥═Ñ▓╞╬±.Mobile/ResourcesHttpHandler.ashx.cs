﻿using System;
using DevExpress.ExpressApp.Mobile;

namespace 家庭财务.Mobile {
    public class ResourcesHttpHandler : MobileResourcesHttpHandler<家庭财务MobileApplication> {
    }
}