﻿Folder Description

The "Controllers" project folder is intended for storing platform-agnostic Controller classes 
that can change the default XAF application flow and add new features.


Relevant Documentation

Controllers and Actions
https://docs.devexpress.com/eXpressAppFramework/112623

Controller Class
https://docs.devexpress.com/eXpressAppFramework/DevExpress.ExpressApp.Controller

ViewController Class
https://docs.devexpress.com/eXpressAppFramework/DevExpress.ExpressApp.ViewController

WindowController Class
https://docs.devexpress.com/eXpressAppFramework/DevExpress.ExpressApp.WindowController
