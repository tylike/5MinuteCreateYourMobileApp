﻿using DevExpress.ExpressApp.DC;
using DevExpress.Persistent.Base;
using DevExpress.Persistent.BaseImpl;
using DevExpress.Xpo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 家庭财务.Module.BusinessObjects
{
    //1，建立收支分类业务对象    //设置默认显示在导航中        //设置默认属性为“分类名称”    [DefaultClassOptions]    [XafDefaultProperty(nameof(分类名称))]    public class 收支分类 : BaseObject
    {
        public 收支分类(Session s):base(s)
        {

        }

        //填加分类名称属性，字符型，必填。
        private string _分类名称;
        public string 分类名称
        {
            get { return _分类名称; }
            set { SetPropertyValue(nameof(分类名称), ref _分类名称, value); }
        }


    }

    //2，建立收支类型枚举
    //收入，支出，两种可用项
    public enum 收支类型
    {
        收入, 支出
    }
    //3，建立收支记录对象
    //设置默认显示在导航中

    [DefaultClassOptions]
    [XafDefaultProperty(nameof(标题))]
    public class 收支记录 : BaseObject
    {
        public 收支记录(Session s) : base(s)
        {

        }
        //填加发生时间属性-datetime
        private DateTime _发生时间;
        public DateTime 发生时间
        {
            get { return _发生时间; }
            set { SetPropertyValue(nameof(发生时间), ref _发生时间, value); }
        }

        //填加收支类型属性
        private 收支类型 _收支类型 ;
        public 收支类型 收支类型 
        {
            get { return _收支类型 ; }
            set { SetPropertyValue(nameof(收支类型 ), ref _收支类型 , value); }
        }

        //填加收支用途属性-string
        private string _收支用途;
        public string 收支用途
        {
            get { return _收支用途; }
            set { SetPropertyValue(nameof(收支用途), ref _收支用途, value); }
        }

        private decimal _发生金额;
        public decimal 发生金额
        {
            get { return _发生金额; }
            set { SetPropertyValue(nameof(发生金额), ref _发生金额, value); }
        }


        //填加标题属性 = 发生时间 + 收支类型 + 收支用途
        public string 标题
        {
            get
            {
                return string.Format("{0} {1} {2} {3}元", 发生时间.ToString("yyyy-MM-dd HH:mm"), 收支类型, 收支用途, 发生金额);
            }
        }

        //显示的结果为 2020-02-13 12:45 支出 买菜[156]元
        //设置标题属性为类型的默认属性

        //填加收支分类属性
        private 收支分类 _收支分类;
        public 收支分类 收支分类
        {
            get { return _收支分类; }
            set { SetPropertyValue(nameof(收支分类), ref _收支分类, value); }
        }
    }
}
